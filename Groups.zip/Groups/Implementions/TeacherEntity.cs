using Groups.Implementions;

namespace Students.Implementations;

public class TeacherEntity : PersonEntity
{

}