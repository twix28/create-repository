namespace Groups.Implementions;

public class PersonEntity
{

}