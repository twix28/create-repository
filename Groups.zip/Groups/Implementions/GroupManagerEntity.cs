using Students.Implementations;

namespace Groups.Implementions;

public class GroupManagerEntity
{

}