namespace Groups.Implementions;

public class SubjectEntity
{

}