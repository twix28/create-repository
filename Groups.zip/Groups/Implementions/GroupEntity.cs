using Groups.Implementions;

namespace Groups.Implementions;

public class GroupEntity
{

}