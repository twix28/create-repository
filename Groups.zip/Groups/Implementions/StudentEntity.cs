namespace Groups.Implementions;

public class StudentEntity : PersonEntity
{

}